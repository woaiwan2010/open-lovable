import React from 'react';
import Header from './components/Header';
import Pricing from './components/Pricing';
import FAQ from './components/FAQ';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Header />
      <FAQ />
      <Footer />
    </div>
  );
}

export default App;